﻿namespace AutoCompleteAPI.BusinessEntities
{
    public class Suggestion
    {
        public string Word { get; set; }
        public long Frequency { get; set; }
    }
}
