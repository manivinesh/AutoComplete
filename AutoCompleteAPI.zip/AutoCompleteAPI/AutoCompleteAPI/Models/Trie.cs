﻿using AutoCompleteAPI.BusinessEntities;
using AutoCompleteAPI.Caching;
using AutoCompleteAPI.Data.Utilities;
using AutoCompleteAPI.Models.Interfaces;
using Microsoft.AspNetCore.Routing;

namespace AutoCompleteAPI.Models
{
    public class Trie : ITrie
    {
        private readonly List<Root> _roots;
        private readonly ICacheController _cacheController;

        public Trie(List<Root> roots, ICacheController cacheController)
        {
            _roots = roots;
            _cacheController = cacheController;
        }

        /// <summary>
        /// Get list of word suggestions based on the prefix. It loads it from Cache or from Data Store
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public List<Suggestion> GetSuggestions(string prefix)
        {
            List<Suggestion> suggestions = new List<Suggestion>();
            var prefixHasMoreThanThreeLetters = prefix.Length > 2;

            var possibleRootNodes = GetPossitbleRootNodes(prefix);
            if (possibleRootNodes != null && possibleRootNodes.Count > 0)
            {
                possibleRootNodes.ForEach(root =>
                {
                    if (root.value != null)
                    {
                        /*If the prefix has more than three letters, The target node for search could
                          be inside one of the child node, this will find which child node we need to search to get the matching words */
                        if (prefixHasMoreThanThreeLetters)
                        {
                            var node = root.value.Find(trieNode =>
                                trieNode.Value.Equals(prefix.Substring(0, 3)));

                            if(node != null)
                            {
                                var targetNode = FindTrieNodeForthePrefix(node, prefix);

                                if(targetNode != null)
                                {
                                    CollectWordsFromChildren(targetNode, suggestions);
                                }
                            }
                        }
                        else
                        {
                            root.value.ForEach(trieNode =>
                            {
                                CollectWordsFromChildren(trieNode, suggestions);
                            });
                        }
                    }
                });

                CacheController.Instance.AddOrUpdateCache(prefix, suggestions);
            }

            return suggestions.OrderByDescending(s => s.Frequency).ToList();
        }

        /// <summary>
        /// Based on the Trie DS I am using, I am separating the nodes with two letter prefix
        /// This method will filter the nodes i have to search for the prefix
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        private List<Root> GetPossitbleRootNodes(string prefix)
        {
            var roots = new List<Root>();

            switch (prefix.Length)
            {
                case 1:
                    roots = _roots.Where(r => r.prefix.StartsWith(prefix)).ToList();
                    break;
                case 2:
                    roots = _roots.Where(r => r.prefix.Equals(prefix)).ToList();
                    break;
                default:
                    roots = _roots.Where(r => r.prefix.Equals(prefix.Substring(0, 2))).ToList();
                    break;

            }

            return roots;
        }

        /// <summary>
        /// If the prefix has more than three letters, The target node for search could
        /// be inside one of the child node, this will find which child node we need to search to get the matching words
        /// </summary>
        /// <param name="currentNode"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        private TrieNode FindTrieNodeForthePrefix(TrieNode currentNode, string prefix)
        {
            if (currentNode != null)
            {
                if (currentNode.Value.Equals(prefix))
                    return currentNode;

                if (currentNode.Children != null && currentNode.Children.Count > 0)
                {
                    foreach (var node in currentNode.Children)
                    {
                        var res = node.Value.Length == prefix.Length
                            ? node.Value == prefix
                            : prefix.StartsWith(node.Value);

                        if (res)
                        {
                            var result = FindTrieNodeForthePrefix(node, prefix);
                            if (result != null)
                            {
                                return result;
                            }
                        }

                    }
                }
            }

            return currentNode;
        }

        /// <summary>
        /// Recursive Function to get all the words
        /// </summary>
        /// <param name="currentNode"></param>
        /// <param name="suggestions"></param>
        private void CollectWordsFromChildren(TrieNode currentNode, List<Suggestion> suggestions)
        {
            if (currentNode.IsWord)
            {
                suggestions.Add(new Suggestion()
                {
                    Frequency = currentNode.Rank,
                    Word = currentNode.Value
                });
            }

            if (currentNode.Children != null && currentNode.Children.Count > 0)
            {
                currentNode.Children.ForEach(node =>
                {
                    CollectWordsFromChildren(node, suggestions);
                });
            }
        }
    }
}
