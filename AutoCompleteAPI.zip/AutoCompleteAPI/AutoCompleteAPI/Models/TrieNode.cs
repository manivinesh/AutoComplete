﻿namespace AutoCompleteAPI.Models
{
    public class TrieNode
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public Int64 Rank { get; set; }
        public bool IsWord { get; set; }
        public List<TrieNode> Children { get; set; }

        #region ForLocalTesting
        public TrieNode()
        {

        }
        #endregion

        public TrieNode(string key, string value, Int64 rank, bool isWord, List<TrieNode> children)
        {
            Key = key;
            Value = value;
            Rank = rank;
            Children = children ?? new List<TrieNode>();
            IsWord = isWord;
        }
    }
}
