﻿namespace AutoCompleteAPI.Models
{
    public class Root
    {
        public int _id { get; set; }
        public string prefix { get; set; }
        public List<TrieNode> value { get; set; }
    }
}
