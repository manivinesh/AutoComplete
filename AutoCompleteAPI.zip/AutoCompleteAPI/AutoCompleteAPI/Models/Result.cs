﻿using AutoCompleteAPI.BusinessEntities;

namespace AutoCompleteAPI.Models
{
    public class Result
    {
        public List<Suggestion> Suggestions { get; set; }
        public DateTime LastRefreshDateTime { get; set; }
    }
}
