﻿using AutoCompleteAPI.BusinessEntities;

namespace AutoCompleteAPI.Models.Interfaces
{
    public interface ITrie
    {
        List<Suggestion> GetSuggestions(string prefix);
    }
}
