(function () {
    "use strict";
    let inputField = document.getElementById('input');
    let ulField = document.getElementById('suggestions');
    let searchBtn = document.getElementById('search');
    let searchContentField = document.getElementById('searchedContent');
    inputField.addEventListener('input', changeAutoComplete);
    ulField.addEventListener('click', selectItem);
    searchBtn.addEventListener('click', searchItem);

  
    async function changeAutoComplete({ target }) {
      let data = target.value;
      ulField.innerHTML = ``;
      if (data.length > 0) {
        let autoCompleteValues = await autoComplete(data);
        autoCompleteValues.forEach(value => { addItem(value.word); });
      }
    }
  
    async function autoComplete(inputValue) {
        const url = `https://localhost:5000/Suggestions/GetSuggestions?prefix=${inputValue}`;
         const response = await fetch(url);
         const data = await response.json();
         return data;
    }
  
    function addItem(value) {
      ulField.innerHTML = ulField.innerHTML + `<li>${value}</li>`;
    }
  
    function selectItem({ target }) {
      if (target.tagName === 'LI') {
        inputField.value = target.textContent;
        ulField.innerHTML = ``;
      }
    }

    async function searchItem() {
        const url = `https://localhost:5000/Suggestions/IncreaseFrequency?word=${inputField.value}`;
         const response = await fetch(url, {
             method: 'POST'
         });
         const data = await response.json();
         return data;
    }
  })();