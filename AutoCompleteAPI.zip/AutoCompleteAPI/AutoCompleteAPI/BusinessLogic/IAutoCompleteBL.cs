﻿using AutoCompleteAPI.BusinessEntities;

namespace AutoCompleteAPI.BusinessLogic
{
    public interface IAutoCompleteBL
    {
        bool IncreaseFrequency(string word);
        List<Suggestion> GetSuggestions(string prefix);
    }
}
