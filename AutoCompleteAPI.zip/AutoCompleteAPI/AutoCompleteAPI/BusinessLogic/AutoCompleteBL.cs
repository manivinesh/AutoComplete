﻿using AutoCompleteAPI.BusinessEntities;
using AutoCompleteAPI.Caching;
using AutoCompleteAPI.Data;
using AutoCompleteAPI.Data.Interfaces;
using AutoCompleteAPI.Data.Utilities;
using AutoCompleteAPI.Models;
using AutoCompleteAPI.Models.Interfaces;

namespace AutoCompleteAPI.BusinessLogic
{
    public class AutoCompleteBL : IAutoCompleteBL
    {
        private readonly ICacheController _cacheController;
        private readonly IDataRepository _repository;
        private readonly ITrie _trie;
        private readonly IFileReader _fileReader;
        private readonly List<Root> _roots;

        public AutoCompleteBL(ICacheController cacheController = null, IDataRepository repository = null, ITrie trie = null, IFileReader fileReader = null)
        { 
            _cacheController = cacheController ?? CacheController.Instance;
            _fileReader = fileReader ?? FileReader.Instance;
            _repository = repository ?? new FileDataRepository(_fileReader);
            _roots = _repository.LoadDataAndMapTrie();

            if(_roots != null)
            {
                _trie = trie ?? new Trie(_roots, _cacheController);
            }
        }

        public List<Suggestion> GetSuggestions(string prefix)
        {
            List<Suggestion> suggestions = new List<Suggestion>();

            if (_cacheController.PrefixSuggestionMappingList != null && _cacheController.PrefixSuggestionMappingList.Count > 0)
            {
                suggestions = _cacheController.GetSuggestionList(prefix);
            }

            if ((suggestions == null || suggestions.Count == 0) && _trie != null)
            {
                suggestions = _trie.GetSuggestions(prefix);
            }

            if (suggestions != null && suggestions.Count > 0)
            {
                return suggestions.OrderByDescending(s => s.Frequency).ToList();
            }

            return new List<Suggestion>();
        }

        public bool IncreaseFrequency(string word)
        {
            _repository.IncreaseFrequency(word);
                        
            return true;
        }
    }
}
