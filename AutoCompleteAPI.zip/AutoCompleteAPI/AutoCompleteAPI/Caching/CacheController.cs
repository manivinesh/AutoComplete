﻿using AutoCompleteAPI.BusinessEntities;
using AutoCompleteAPI.Controllers;
using AutoCompleteAPI.Data.Utilities;
using AutoCompleteAPI.Models;
using System.Collections.Concurrent;

namespace AutoCompleteAPI.Caching
{
    public class CacheController : ICacheController
    {
        private const int CacheCleanupIntervalSeconds = 10;
        private const int CacheSizeLimit = 100;
        private const int CacheItemExpirationSeconds = 20;
        private static long NextRefresh = 0;

        private static ConcurrentDictionary<string, Result> prefixSuggestionMappingList = null;
        private static readonly object LockobjCacheRefresh = new object();

        private static CacheController _instance = null;
        private static readonly object _lock = new object();

        public static CacheController Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new CacheController();
                    }

                    return _instance;
                }
            }
        }

        public ConcurrentDictionary<string, Result> PrefixSuggestionMappingList
        {
            get
            {
                try
                {
                    if (prefixSuggestionMappingList == null)
                    {
                        prefixSuggestionMappingList = new ConcurrentDictionary<string, Result>();
                    }
                    else
                    {
                        if (NextRefresh < DateTime.UtcNow.Ticks || prefixSuggestionMappingList.Count >= CacheSizeLimit)
                        {
                            NextRefresh = DateTime.UtcNow.AddSeconds(CacheCleanupIntervalSeconds).Ticks;
                            Task.Run(() => RefreshCache());
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

                return prefixSuggestionMappingList;
            }
            set
            {
                prefixSuggestionMappingList = value;
            }
        }

        public List<Suggestion> GetSuggestionList(string prefix)
        {
            Result result = new Result();
            var data = prefixSuggestionMappingList.TryGetValue(prefix, out result);

            if (result?.Suggestions != null && result.Suggestions.Count > 0)
            {
                return result.Suggestions;
            }

            return new List<Suggestion>();
        }

        public bool AddOrUpdateCache(string prefix, List<Suggestion> suggestions)
        {
            Result result = new Result();
            result.Suggestions = suggestions;
            result.LastRefreshDateTime = DateTime.UtcNow;
           
            prefixSuggestionMappingList.AddOrUpdate(prefix, result, (key, value) => result);

            return true;
        }

        private bool RefreshCache()
        {
            try
            {
                lock(LockobjCacheRefresh)
                {
                    if (prefixSuggestionMappingList != null && prefixSuggestionMappingList.Count > 0)
                    {
                        var spanCacheItem = DateTime.UtcNow.AddSeconds(CacheItemExpirationSeconds * -1);

                        var cleanUpData =
                            prefixSuggestionMappingList.Where(suggestionList =>
                                spanCacheItem >= suggestionList.Value.LastRefreshDateTime);

                        Remove(cleanUpData.ToList());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return true;
        }

        private void Remove(List<KeyValuePair<string, Result>> data)
        {
            if (data != null && data.Count > 0)
            {
                foreach (var d in data)
                {
                    prefixSuggestionMappingList.TryRemove(d.Key, out Result val);
                }
            }
        }
    }
}
