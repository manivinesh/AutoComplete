﻿using AutoCompleteAPI.BusinessEntities;
using AutoCompleteAPI.Models;
using System.Collections.Concurrent;

namespace AutoCompleteAPI.Caching
{
    public interface ICacheController
    {
        ConcurrentDictionary<string, Result> PrefixSuggestionMappingList { get; set; }
        List<Suggestion> GetSuggestionList(string prefix);
        bool AddOrUpdateCache(string prefix, List<Suggestion> suggestions);
    }
}
