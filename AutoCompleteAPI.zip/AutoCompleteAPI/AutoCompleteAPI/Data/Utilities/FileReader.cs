﻿using AutoCompleteAPI.Data.Interfaces;
using AutoCompleteAPI.Models;
using Json.Net;

namespace AutoCompleteAPI.Data.Utilities
{
    public class FileReader : IFileReader
    {
        private static List<Root> _roots = null;
        private static FileReader _instance = null;
        private static readonly object _lock = new object();

        public static FileReader Instance
        {
            get
            {
                lock(_lock )
                {
                    if (_instance == null)
                    {
                        _instance = new FileReader();
                    }

                    return _instance;
                }
            }
        }

        public List<Root> Roots
        {
            get
            {
                if (_roots == null)
                {
                    var path = $"{Environment.CurrentDirectory}{Path.DirectorySeparatorChar}input.json";
                    using (StreamReader reader = new StreamReader(path))
                    {
                        string json = reader.ReadToEnd();
                        _roots = JsonNet.Deserialize<List<Root>>(json);
                    }
                }

                return _roots;
            }
        }
    }
}
