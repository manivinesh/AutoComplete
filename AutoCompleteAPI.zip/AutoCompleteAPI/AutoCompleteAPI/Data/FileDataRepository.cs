﻿using AutoCompleteAPI.BusinessEntities;
using AutoCompleteAPI.Data.Interfaces;
using AutoCompleteAPI.Models;

namespace AutoCompleteAPI.Data
{
    public class FileDataRepository : IDataRepository
    {
        private readonly IFileReader _reader;

        public FileDataRepository(IFileReader reader) 
        {
            _reader = reader;
        }

        public List<Root> LoadDataAndMapTrie()
        {
            return _reader.Roots;
        }

        public bool IncreaseFrequency(string word)
        {
            if(_reader.Roots == null || _reader.Roots.Count == 0) { return false; }

            var roots = _reader.Roots.Find(root => root.prefix.Equals(word.Substring(0,2)));

            if(roots != null)
            {
                roots.value.ForEach(trieNode =>
                {
                    FindWordAndIncreaseFrequency(trieNode, word);
                });
            }

            return true;
        }

        private TrieNode FindWordAndIncreaseFrequency(TrieNode currentNode, string word)
        {
            if (currentNode != null)
            {
                if (currentNode.Value.Equals(word))
                {
                    currentNode.Rank++;
                    return currentNode;
                }

                if (currentNode.Children != null && currentNode.Children.Count > 0)
                {
                    foreach(var node in currentNode.Children)
                    {
                        var result = FindWordAndIncreaseFrequency(node, word);
                        if(result != null)
                        {
                            return result;
                        }
                    }
                }
            }

            return null;
        }
    }
}
