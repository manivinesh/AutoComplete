﻿using AutoCompleteAPI.Models;

namespace AutoCompleteAPI.Data.Interfaces
{
    public interface IFileReader
    {
        List<Root> Roots { get; }
    }
}
