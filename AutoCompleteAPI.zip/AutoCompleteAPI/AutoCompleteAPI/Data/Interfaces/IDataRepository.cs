﻿using AutoCompleteAPI.Models;

namespace AutoCompleteAPI.Data.Interfaces
{
    public interface IDataRepository
    {
        List<Root> LoadDataAndMapTrie();
        bool IncreaseFrequency(string word);
    }
}
