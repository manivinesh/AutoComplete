﻿using AutoCompleteAPI.BusinessLogic;
using AutoCompleteAPI.Caching;
using AutoCompleteAPI.Data;
using AutoCompleteAPI.Data.Interfaces;
using AutoCompleteAPI.Data.Utilities;
using AutoCompleteAPI.Models;
using AutoCompleteAPI.Models.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace AutoCompleteAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [EnableCors("_allowAllOrigins")]
    public class SuggestionsController : ControllerBase
    {
        ICacheController cacheController = CacheController.Instance;
        IDataRepository repository = new FileDataRepository(FileReader.Instance);
        IAutoCompleteBL autoCompleteBL = new AutoCompleteBL();

        [HttpGet(template: "GetSuggestions")]
        public IActionResult Get(string prefix)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(prefix))
                    return BadRequest("Prefix is Empty");

                return Ok(autoCompleteBL.GetSuggestions(prefix));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "API Error");
            }
        }

        [HttpPost(template: "IncreaseFrequency")]
        public IActionResult Post(string word)
        {
            try
            {
                return Ok(autoCompleteBL.IncreaseFrequency(word));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "API Error");
            }
        }
    }
}
